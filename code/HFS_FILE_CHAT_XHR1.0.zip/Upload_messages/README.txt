This folder must to be uploadable if you will using HFS server.

To set up this folder:
1. Drag and drop chat folder to HFS.
2. Then drag and drop this folder inside previous folder in HFS.
3. HFS will ask you "Do you want ANYONE to be able to upload to this folder?", because UPLOAD words found in the name of this folder.
4. OK, YES, uploadable for anyone.
	Then you can hide this folder: Right click on folder -> Properties -> Flags -> Hidden, Recursively hidden...
	
Best regards, and have a nice day...